import logo from './logo.svg';
import './App.css';
import Parent from './components/parent'
import Ref from './components/refs'
import Ref1 from './components/refparent'
import Portals from './components/portals'
import Err from './components/Hero'
import Boundary from './components/error'
import C from './components/counter'
import D from './components/counter2'
import E from './components/render'
import ComponentA from './components/context1/A'
import {UserProvider } from './components/context1/context'
function App() {
  return (
    <div className="App">
    {/*
    <Boundary>
    <Err name="batman"/> 
    <Err name="joker"/> 
    </Boundary> 
    <C name="pavan"/> 
    <E render={(count,handle) =>
					<D
						count={count}
						handle={handle}>
    </D>} /> */}
    <UserProvider value="pavan">
      <ComponentA />
    </UserProvider>
    </div>
  );
}

export default App;
