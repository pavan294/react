import React, { Component } from 'react'

export class reg extends Component {
    render() {
        console.log("regular component")
        return (
            <div>
            reg component {this.props.name}
            </div>
        )
    }
}

export default reg
