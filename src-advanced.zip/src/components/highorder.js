import React, { Component } from 'react'
const update=(Original,inc)=>{
    class New extends Component{
        constructor(props) {
            super(props)
        
            this.state = {
                count : 0
            }
        }
        handle = () => {
            this.setState(prevState => {
             return {
                count: prevState.count + inc
              }
            })
          }
        render(){
            return <Original count={this.state.count} handle={this.handle} {...this.props}/>
        }
    }
    return New
}


export default update
