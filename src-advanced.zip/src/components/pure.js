import React, { PureComponent } from 'react'

class pure extends PureComponent {
    render() {
        console.log('Pure Comp render')
        return (
            <div>
            pure component {this.props.name}
            </div>
        )
    }
}

export default pure
