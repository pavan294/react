import React, { Component } from 'react'
import Child from './refchild'
export class refparent extends Component {
    constructor(props) {
        super(props)
        this.ref=React.createRef()
    }
    
    render() {
        return (
            <div>
                <Child ref={this.ref}/>
                <button onClick={()=>this.ref.current.focusInput()}>click</button>
            </div>
        )
    }
}

export default refparent
