import React, { Component } from 'react'

export class refs extends Component {
    constructor(props) {
        super(props)
        this.ref=React.createRef()
    }
    focusInput(){
        this.ref.current.focus()
    }
    
    render() {
        return (
            <div>
            <input type="text" ref={this.ref} />
            </div>
        )
    }
}

export default refs
