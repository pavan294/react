import React, { Component } from 'react'

export class refs extends Component {
    constructor(props) {
        super(props)
        this.ref=React.createRef()
    }
    componentDidMount(){
        this.ref.current.focus()
    }
    
    render() {
        return (
            <div>
            <input type="text" ref={this.ref} />
            <button onClick={()=>alert(this.ref.current.value)}>+</button>
            </div>
        )
    }
}

export default refs
