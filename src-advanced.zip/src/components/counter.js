import React, { Component } from 'react'
import r from './highorder'
export class counter extends Component {
    render() {
        return (
            <div>
            <button onClick={this.props.handle}>click {this.props.count}</button> 
            </div>
        )
    }
}

export default r(counter,5)
