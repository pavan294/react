import React from 'react'
import ReactDOM from 'react-dom'
function Portals() {
    return ReactDOM.createPortal(
        <div>
           portal
        </div>,
        document.getElementById('portal-root')
    )
}

export default Portals
