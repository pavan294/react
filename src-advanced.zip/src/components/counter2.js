import React, { Component } from 'react'
export class Counter2 extends Component {
    render() {
        return (
            <div>
            <button onClick={this.props.handle}> click {this.props.count}</button> 
            </div>
        )
    }
}

export default Counter2
