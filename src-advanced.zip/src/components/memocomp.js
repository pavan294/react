import React from 'react'

function memocomp(props) {
    console.log("memo")
    return (
        <div>
        {props.name}
        </div>
    )
}

export default React.memo(memocomp)
