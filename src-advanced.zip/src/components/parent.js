import React, { Component,PureComponent  } from 'react'
import R from './pure'
import P from './reg'
import K from './memocomp'
export class parent extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             name:"pavan"
        }
    }
    componentDidMount(){
    let k = setInterval(()=>this.setState({
            name:"vishwas"
        }),2000)
    }
    componentWillUnmount(){
        clearInterval(this.k)
    }
    render() {
        console.log("parent")
        return (
            <div>
              parent
              {/*
              <R name={this.state.name} />
              <P name={this.state.name} /> */}
              <K name={this.state.name} />
            </div>
        )
    }
}

export default parent
