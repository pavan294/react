import C from './C'
import Z from './context'
import React, { Component } from 'react'
class B extends Component {
     static contextType=Z
     render() {
         return (
             <div>
             componentB {this.context}
             <C />   
             </div>
         )
     }
 }
export default B
