import React, { useState} from 'react'
import axios from 'axios'

function DataFetching() {
	const [post, setPost] = useState({name:'',car_id:''})
	const [id, setId] = useState(1)
	const [idFromButtonClick, setIdFromButtonClick] = useState(1)

	const handleClick = () => {
		console.log("clicked")
		setIdFromButtonClick(id)
		axios.delete(`http://localhost:5000/mechanics/${id}`)
			.then(res => {
        const data =res.data[0]
		console.log(res.data[0])
        setPost(data)
			})
			.catch(err => {
				console.log(err)
			})
	}

	return (
		<div>
			<input type="text" value={id} onChange={e => setId(e.target.value)} />
			<button type="button" onClick={()=>{handleClick()}}>DELETE</button>
		</div>
	)
}

export default DataFetching