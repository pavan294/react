import React, { useState, useEffect } from 'react'
import axios from 'axios'
function Fetch() {
	const [posts, setPost] = useState({name:'',car_id:'','_id':''})
    let handler = (e)=>{ 
        e.preventDefault();
        axios
            .put(`http://localhost:5000/mechanics/${posts._id}`,
            posts)
            .then(res => {
                console.log(res.data);
                })
            .catch(err =>{
                console.log(err)
            })
    
    }
	return (
		<div>
        <form onSubmit={handler}>
        <label>name</label>:
        <input type="text" value={posts.name} onChange={e =>setPost({...posts, name:e.target.value})} />
        <br />
        <label>car_id</label>:
        <input type="text" value={posts.car_id} onChange={e =>setPost({...posts, car_id:e.target.value})} />
        <br />
        <label>id</label>:
        <input type="text" value={posts._id} onChange={e =>setPost({...posts, _id:e.target.value})} />
        <br />
        <button type="submit">MECHANICPUT</button>
        </form>
        <label>output</label>:
        <div>{posts.name}---{posts.car_id}</div>
        </div>
	)
}

export default Fetch