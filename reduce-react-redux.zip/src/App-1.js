import logo from './logo.svg';
import './App.css';
import React,{ createContext } from 'react';
import {
  BrowserRouter as Router,
  Route,
  Switch,
  withRouter
} from "react-router-dom";
import FetchId from './components/fetch1'
import PATCH from './components/car_patch'
import PUT from './components/car_put'
import POST from './components/post'
import Home from './components/fetch'
export const Context = React.createContext()
function App() {
  let state=[]
  return (
    <Router>
    <div className="App">
    <Switch>
          <Route exact path="/cars/add" component={POST} />
          <Route exact path="/cars/edit/:id" component={PUT} />
          <Route exact path="/cars/patch/:id" component={PATCH} />
        </Switch>
    
    <Context.Provider value={state}>
    <Home />
    </Context.Provider>

    </div>
    </Router>
  );
}

export default App;
