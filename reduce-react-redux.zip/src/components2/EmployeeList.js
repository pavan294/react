import React, { useContext } from 'react';
import { Link } from 'react-router-dom';

import { GlobalContext } from '../context/GlobalState';

export const EmployeeList = () => {
  const { employees, removeEmployee } = useContext(GlobalContext);
  return (
    <React.Fragment>
          {employees.map((employee) => (
            <div key={employee.id}>
                  {employee.name}--{employee.designation}--{employee.location}
                <Link
                  to={`/edit/${employee.id}`}
                  title="Edit Employee"
                >edit
                </Link>
                <button
                  onClick={() => removeEmployee(employee.id)}
                >remove </button>

                </div>
          ))}
        </React.Fragment>
      )}