import React, { useState, useContext } from 'react';
import { Link, useHistory } from 'react-router-dom';

import { GlobalContext } from '../context/GlobalState';

export const AddEmployee = () => {
  let history = useHistory();

  const { addEmployee, employees } = useContext(GlobalContext);

  const [name, setName] = useState("");
  const [location, setLocation] = useState("");
  const [designation, setDesignation] = useState("");

  const onSubmit = (e) => {
    e.preventDefault();
    const newEmployee = {
      id: employees.length + 1,
      name,
      location,
      designation,
    };
    addEmployee(newEmployee);
    history.push("/");
  };

  return (
    <React.Fragment>
        <form onSubmit={onSubmit}>
          <label>Name</label>
          <input value={name} onChange={(e) => setName(e.target.value)} type="text"/>
          <br />
          <label>color</label>
            <input value={location} onChange={(e) => setLocation(e.target.value)}
              placeholder="Enter location"
            />
          <br />
          <label>cost</label>
          <input value={designation}
              onChange={(e) => setDesignation(e.target.value)}
              type="text"
            />
          <br />
          <button type="submit">Add Employee </button><br />
            <Link to="/">Cancel</Link>
        </form>
    </React.Fragment>
  );
};