import React from "react";
import { Link } from "react-router-dom";

export const Heading = () => {
  return (
    <div>
    <Link to="/add">
    <button>Add Employee
    </button>
    </Link>
    </div>

  );
};