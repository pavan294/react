import React from 'react'
import {buyCake} from '../redux'
import {useSelector,useDispatch} from 'react-redux'
function HookCakeContainer() {
    const numOfCakes=useSelector((state)=>state.cake.numOfCakes)
    const dispatch= useDispatch()
    return (
        <center>
        <div>
        <h1> num of cakes-{numOfCakes} </h1> 
        <button onClick={()=>dispatch(buyCake())}> buyCake </button>  
        </div>
        </center>
    )
}

export default HookCakeContainer
