import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { useHistory, useParams } from "react-router-dom";
function Fetch(props) {
	const [posts, setPost] = useState({name:null,cost:null,color:null})
    const { id } = useParams();
    let handler = (e)=>{ 
        e.preventDefault();
        console.log()
        axios
            .patch(`http://localhost:5000/cars/${id}`,
            posts)
            .then(res => {
                console.log(res.data);
                })
            .catch(err =>{
                console.log(err)
            })
    
    }
	return (
		<div>
        <form onSubmit={handler}>
        <label>name</label>:
        <input type="text" value={posts.name} onChange={e =>setPost({...posts, name:e.target.value})} />
        <br />
        <label>color</label>:
        <input type="text" value={posts.color} onChange={e =>setPost({...posts, color:e.target.value})} />
        <br />
        <label>cost</label>:
        <input type="text" value={posts.cost} onChange={e => setPost({...posts, cost:e.target.value})} />
        <br />
        <button type="submit">CARPATCH</button>
        </form>
        <label>output</label>:
        <div>{posts.name}{posts.color}{posts.cost}</div>
        </div>
	)
}

export default Fetch