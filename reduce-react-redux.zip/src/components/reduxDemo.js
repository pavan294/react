import {createStore} from 'redux';
import React, { Component } from 'react'

class reduxDemo extends Component {
    render() {
        const reducer=function(state,action){
            if (action.type=="increment"){
               console.log(state)
               return state+1}
            else if (action.type=="decrement")
               return state-1
            else
               return state
        }
        const store=createStore(reducer,0)
        return (
            <div>
            <button onClick={()=>store.dispatch({type:"increment"})}>+</button>
            <button onClick={()=>store.dispatch({type:"decrement"})}>-</button>
            <div>{store.getState()}</div>
            </div>
        )
    }
}

export default reduxDemo
