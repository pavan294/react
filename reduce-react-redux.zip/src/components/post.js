import React, { useState, useEffect, useContext } from 'react'
import { Redirect } from 'react-router'
import axios from 'axios'
import {Context} from  '../App-1'
import { Link} from 'react-router-dom';
function Fetch(props) {
    const [list, setList] = useState(props.state)
	const [posts, setPost] = useState({name:'',cost:'',color:''})
    let handler = (e)=>{ 
        e.preventDefault();
        axios
            .post(`http://localhost:5000/cars/`,
            posts)
            .then(res => {
                console.log(res);
                console.log(list)
                setList(posts)
                })
            .catch(err =>{
                console.log(err.response.data)
            })
    
    }
	return (
		<div>
        <form onSubmit={handler}>
        <label>name</label>:
        <input type="text" value={posts.name} onChange={e =>setPost({...posts, name:e.target.value})} />
        <br />
        <label>color</label>:
        <input type="text" value={posts.color} onChange={e =>setPost({...posts, color:e.target.value})} />
        <br />
        <label>cost</label>:
        <input type="text" value={posts.cost} onChange={e => setPost({...posts, cost:e.target.value})} />
        <br />
		<br />
        <button type="submit">AddCAR</button>
        </form><br />
        <Link to="/">Home</Link>
        </div>
	)
}

export default Fetch