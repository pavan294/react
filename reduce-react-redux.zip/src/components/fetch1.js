import React, { useState, useEffect } from 'react'
import axios from 'axios'
import Post from './post'
import Put from './car_put'
import Patch from './car_patch'
import { Link } from "react-router-dom";
function Fetch() {
	const [posts, setPost] = useState([])
    let car_delete= (e) =>{
	    axios.delete(`http://localhost:5000/cars/${e.target.value}`)
			.then(res => {
            setPost(posts.filter(item => item._id !== e.target.value));
			})
			.catch(err => {
				console.log(err)
			})
        
    }
	useEffect(() => {
			axios.get('http://localhost:5000/cars/CarsList')
			.then(res => {
        console.log(res)
        setPost(res.data)
			})
			.catch(err => {
				console.log(err)
			})
	},[])
	return (
		<div>
        <Link to="/cars/add">Add Car</Link>
        <center>
        <table>
            <tr>
            <th>name</th>
            <th>color</th>
            <th>cost</th>
            <th>put</th>
            <th>patch</th>
            <th>delete</th>
            </tr>
            {posts.map(post => (
            <tr key={post._id.$oid}>
            <td>{post.name}</td>
            <td>{post.color}</td>
            <td>{post.cost}</td>
            <td><Link to={`/cars/edit/${post._id.$oid}`}> put</Link></td>
            <td><Link to={`/cars/patch/${post._id.$oid}`}>patch</Link></td>
            <td><button onClick={car_delete}value={post._id.$oid}>delete</button></td>
            </tr>))}
        </table>
        </center>
        </div>
	)
}

export default Fetch