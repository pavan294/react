import React from 'react'
import {buyIceCream} from '../redux'
import {connect} from 'react-redux'
function IceCreamContainer(props) {
    return (
        <div>
        <center>
        <h2>number of icecreams-{props.numOfIceCreams}</h2>
        <button onClick={props.buyIceCream}>buyicecream</button>
        </center>
        </div>
    )
}
const mapStateToProps = state =>{
    return{
        numOfIceCreams:state.icecream.numOfIceCreams
    }
}
const mapDispatchToProps=(dispatch)=>{
    return {
        buyIceCream:()=>dispatch(buyIceCream())
      }

}
export default connect(mapStateToProps,mapDispatchToProps)(IceCreamContainer)
