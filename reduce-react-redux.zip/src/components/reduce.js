import React, {useReducer,useContext} from 'react'
import {Context} from  '../App'
let reducer=(state,action)=>{
    switch(action.type){
        case "increment":
            return state+1
        case "decrement":
            return state-1
        default:
            return state
    }
}
function Reduce() {
    let state=useContext(Context)
    console.log(state)
    const [newstate,dispatch]=useReducer(reducer,state)
    return (
        <div>
        <button onClick={()=>dispatch({type:"post"})}>+</button>
        <button onClick={()=>dispatch({type:"decrement"})}>-</button>
        </div>
    )
}

export default Reduce
