import React from 'react'
import Redux from './components/CakeContainer'
import Redux1 from './components/HookCakeContainer'
import Redux2 from './components/IceCreamContainer'
import Redux3 from './components/NewCakeContainer'
import {Provider} from 'react-redux'
import store from './redux/store'
function App() {
    return (
        <Provider store={store}>
        <div className="App">
        <Redux />
        <Redux1 />
        <Redux2 />
        <Redux3 />
        </div>
        </Provider>
    );
  }
  
  export default App;