import './App.css';
import {
  BrowserRouter as Router,
  Route,
  Switch,
} from "react-router-dom";
import {Provider} from 'react-redux'
import store from './redux/store'
import PATCH from './components/car_patch'
import PUT from './components/car_put'
import POST from './components/post'
import Home from './components/fetch'
function App() {
  return (
    <Router>
    <Provider store={store}>
    <div className="App">
    <Switch>
          <Route exact path="/cars/add" component={POST} />
          <Route exact path="/cars/edit/:id" component={PUT} />
          <Route exact path="/cars/patch/:id" component={PATCH} />
        </Switch>
    <Home />
    </div>
    </Provider>
    </Router>
  );
}

export default App;
