import {GET,DELETE,POST,PUT,PATCH} from './types'
import axios from 'axios'
export const getitem=(payload)=>{
    return {
        type:GET,
        payload:payload
        
    }
}
export const deleteitem=(id)=>{
	axios.delete(`http://localhost:5000/cars/${id}`)
	.then(res => {
        console.log(res.data)})
	.catch(err => {
		console.log(err)
		})
    return {
        type:DELETE,
        payload:id
        }   
    }
export const Postitem=(dispatch,data)=>{
    axios
    .post('http://localhost:5000/cars/',data)
    .then(res => {
        dispatch({
            type:POST,
            payload:res.data
            })
        console.log(res.data)   
        })
    .catch(err =>{
        console.log(err)
    })
    }
export const Putitem=(dispatch,id,payload)=>{
    axios
    .put(`http://localhost:5000/cars/${id}`,payload)
    .then(res => {
        console.log(res.data,id)
        dispatch({
            type:PUT,
            payload:res.data,
            })
                })
    .catch(err =>{
        console.log(err)
            })
        }
export const Patchitem=(dispatch,id,payload)=>{
            axios
            .patch(`http://localhost:5000/cars/${id}`,payload)
            .then(res => {
                console.log(res.data,id)
                dispatch({
                    type:PATCH,
                    payload:res.data,
                    })
                        })
            .catch(err =>{
                console.log(err)
                    })
                }