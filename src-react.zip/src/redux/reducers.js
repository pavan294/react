import {GET,DELETE,POST,PUT,PATCH} from './types'
const initialState={
    cars:[]
}
const Reducer=(state=initialState,action)=>{
    switch(action.type){
        case GET:
            return{
                ...state,
                cars:[...state.cars,...action.payload]
            }
        case DELETE:
            return{
                ...state,
                cars:state.cars.filter((car)=>car._id.$oid!==action.payload)
                }   
        case POST:
            return{
                 ...state,
                cars:[...state.cars,action.payload]
                }   
        case PUT:
            let data=action.payload[0]
            let index=state.cars.findIndex((car)=>car._id.$oid===data._id.$oid)
            state.cars[index]=data
            return{
                ...state,
                cars:[...state.cars]
                }
        case PATCH:
            let patch_data=action.payload[0]
            let patch_index=state.cars.findIndex((car)=>car._id.$oid===patch_data._id.$oid)
            state.cars[patch_index]=patch_data
            return{
                ...state,
                cars:[...state.cars]
                }
        default:
            return state
    }
}
export default Reducer