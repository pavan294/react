import React from 'react'
import {useDispatch} from 'react-redux'
import {Putitem} from '../redux/actions'
import { Form, Input, Button} from 'antd';
import { EditOutlined } from '@ant-design/icons';
import { useParams } from "react-router-dom";
function Fetch() {
    const { id } = useParams();
    const dispatch= useDispatch()
	return (
		<div>
        <Form onFinish={(e)=>Putitem(dispatch,id,{name:e.name,color:e.color,cost:parseInt(e.cost)})}>
        <Form.Item rules={[{ required: true}]} style={{width:'30%',marginLeft: "600px",marginTop: "50px"}} label="name" name="name">
        <Input placeholder="name" required></Input>
        </Form.Item>
        <Form.Item rules={[{ required: true}]} style={{width:'30%',marginLeft: "600px" }} label="color" name="color">
        <Input placeholder="color" required></Input>
        </Form.Item>
        <Form.Item rules={[{ required: true}]} style={{width:'30%',marginLeft: "600px"}}  label="cost" name="cost">
        <Input placeholder="cost" required></Input>
        </Form.Item>
        <Form.Item rules={[{ required: true }]} style={{ width: "30%",marginLeft: "500px"}} wrapperCol={{ offset: 8, span: 16 }}>
        <Button type="primary" style={{background:"Aquamarine",color:"black"}} htmlType="submit"><EditOutlined /></Button>
        </Form.Item>
        </Form><br />
        </div>
	)
}

export default Fetch