import React, { useState, useEffect } from 'react'
import axios from 'axios'
import {useSelector,useDispatch} from 'react-redux'
import {Postitem} from '../redux/actions'
import { Form, Input, Button} from 'antd';
import { PlusCircleOutlined } from '@ant-design/icons';
import 'antd/dist/antd.css'; 
function Fetch() {
	const [posts, setPost] = useState({name:'',color:'',cost:''})
    const dispatch= useDispatch()
    return (
		<div>
        <Form onFinish={(e)=>Postitem(dispatch,{name:e.name,color:e.color,cost:parseInt(e.cost)})}>
        <Form.Item rules={[{ required: true}]} style={{width:'30%',marginLeft: "600px",marginTop: "50px"}} label="name" name="name">
        <Input placeholder="name" required></Input>
        </Form.Item>
        <Form.Item rules={[{ required: true}]} style={{width:'30%',marginLeft: "600px" }} label="color" name="color">
        <Input placeholder="color" required></Input>
        </Form.Item>
        <Form.Item rules={[{ required: true}]} style={{width:'30%',marginLeft: "600px"}}  label="cost" name="cost">
        <Input placeholder="cost" required></Input>
        </Form.Item>
        <Form.Item rules={[{ required: true }]} style={{ width: "30%",marginLeft: "500px"}} wrapperCol={{ offset: 8, span: 16 }}>
        <Button type="primary" htmlType="submit"><PlusCircleOutlined /></Button>
        </Form.Item>
        </Form><br />
    </div>
	)
}

export default Fetch