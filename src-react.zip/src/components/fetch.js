import React, { useState, useEffect} from 'react'
import axios from 'axios'
import { EditOutlined,DeleteOutlined,PlusCircleOutlined} from '@ant-design/icons';
import { Link } from "react-router-dom";
import {getitem,deleteitem} from '../redux/actions'
import {useSelector,useDispatch} from 'react-redux'
function Container() {
    const cars=useSelector((state)=>state.cars)
    const dispatch=useDispatch()
    useEffect(() => {
        axios.get('http://localhost:5000/cars/CarsList')
        .then(res => {
        dispatch(getitem(res.data))
        })
        .catch(err => {
            console.log(err)
        })
},[])
return (
    <div>
    <Link style={{color:"green"}}to="/cars/add"><PlusCircleOutlined/>ADD</Link>
    <center>
    <table>
    <thead>
        <tr>
        <th>name</th>
        <th>color</th>
        <th>cost</th>
        <th>put</th>
        <th>patch</th>
        <th>delete</th>
        </tr>
    </thead>
        {cars.map(car => (
        <tbody key={car._id.$oid}>
        <tr>
        <td>{car.name}</td>
        <td>{car.color}</td>
        <td>{car.cost}</td>
        <td><Link style={{color:"green"}} to={`/cars/edit/${car._id.$oid}`}><EditOutlined/>put</Link></td>
        <td><Link style={{color:"green"}} to={`/cars/patch/${car._id.$oid}`}><EditOutlined/>patch</Link></td>
        <td><button style={{color:"red"}} onClick={()=>dispatch(deleteitem(car._id.$oid))}><DeleteOutlined/></button></td>
        </tr>
        </tbody>
        ))}
    </table>
    </center>
    </div>
)
}

export default Container
