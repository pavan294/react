import {useDispatch} from 'react-redux'
import {Patchitem} from '../redux/actions'
import { Form, Input, Button} from 'antd';
import { EditOutlined } from '@ant-design/icons';
import { useParams } from "react-router-dom";
function Patch() {
    const { id } = useParams();
    const dispatch= useDispatch()
	return (
		<div>
        <Form onFinish={(e)=>Patchitem(dispatch,id,{name:e.name,color:e.color,cost:parseInt(e.cost)})}>
        <Form.Item style={{width:'30%',marginLeft: "600px",marginTop: "50px"}} label="name" name="name">
        <Input placeholder="name"></Input>
        </Form.Item>
        <Form.Item style={{width:'30%',marginLeft: "600px" }} label="color" name="color">
        <Input placeholder="color"></Input>
        </Form.Item>
        <Form.Item  style={{width:'30%',marginLeft: "600px"}}  label="cost" name="cost">
        <Input placeholder="cost"></Input>
        </Form.Item>
        <Form.Item style={{ width: "30%",marginLeft: "500px"}} wrapperCol={{ offset: 8, span: 16 }}>
        <Button type="primary" style={{background:"Aquamarine",color:"black"}} htmlType="submit"><EditOutlined /></Button>
        </Form.Item>
        </Form><br />
        </div>
	)
}

export default Patch