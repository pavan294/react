import React, { useState} from 'react'
import axios from 'axios'

function DataFetching() {
	const [post, setPost] = useState({name:'',car_id:''})
	const [id, setId] = useState('')
	const [idFromButtonClick, setIdFromButtonClick] = useState('')

	const handleClick = () => {
		console.log("clicked")
		setIdFromButtonClick(id)
		axios.get(`http://localhost:5000/mechanics/${id}`)
			.then(res => {
        const data =res.data[0]
		console.log(res.data[0])
        setPost(data)
			})
			.catch(err => {
				console.log(err)
			})
	}

	return (
		<div>
			<input type="text" value={id} onChange={e => setId(e.target.value)} />
			<button type="button" onClick={()=>{handleClick()}}>Fetch Post</button>
			<div>{post.name}--{post.car_id}</div>
		</div>
	)
}

export default DataFetching