import React, { useState, useEffect } from 'react'
import axios from 'axios'
function Fetch() {
	const [posts, setPost] = useState({name:'',car_id:''})
    let handler = (e)=>{ 
        e.preventDefault();
        axios
            .post(`http://localhost:5000/mechanics/`,
            posts)
            .then(res => {
                console.log(res);
                })
            .catch(err =>{
                console.log(err.response.data)
            })
    
    }
	return (
		<div>
        <form onSubmit={handler}>
        <label>name</label>:
        <input type="text" value={posts.name} onChange={e =>setPost({...posts, name:e.target.value})} />
        <br />
        <label>car_id</label>:
        <input type="text" value={posts.car_id} onChange={e =>setPost({...posts, car_id:e.target.value})} />
        <br />
        <button type="submit">AddMECHANIC</button>
        </form><br />
        <div>{posts.name}---{posts.car_id}</div>
        </div>
	)
}

export default Fetch