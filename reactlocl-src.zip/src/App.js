import logo from './logo.svg';
import './App.css';
import {
  BrowserRouter as Router,
  Route,
  Switch,
  withRouter
} from "react-router-dom";
import FetchId from './components/fetch'
import PATCH from './components/car_patch'
import PUT from './components/car_put'
import POST from './components/post'
import Home from './components/fetch'
function App() {
  return (
    <Router>
    <div className="App">
    <Switch>
          <Route exact path="/cars/add" component={POST} />
          <Route exact path="/cars/edit/:id" component={PUT} />
          <Route exact path="/cars/patch/:id" component={PATCH} />
        </Switch>
    <Home />
    </div>
    </Router>
  );
}

export default App;
