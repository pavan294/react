import React, { useState, useEffect } from 'react'
import axios from 'axios'
import Post from './post'
import Put from './car_put'
import Patch from './car_patch'
import { EditOutlined,DeleteOutlined,PlusCircleOutlined} from '@ant-design/icons';
import { Link } from "react-router-dom";
function Fetch() {
	const [posts, setPost] = useState([])
    let car_delete= (e) =>{
	    axios.delete(`http://localhost:5000/cars/${e.target.value}`)
			.then(res => {
            setPost(posts.filter(item => item._id !== e.target.value));
			})
			.catch(err => {
				console.log(err)
			})
        
    }
	useEffect(() => {
			axios.get('http://localhost:5000/cars/CarsList')
			.then(res => {
        console.log(res)
        setPost(res.data)
			})
			.catch(err => {
				console.log(err)
			})
	},[])
	return (
		<div>
        <Link style={{color:"green"}}to="/cars/add"><PlusCircleOutlined/>ADD</Link>
        <center>
        <table>
            <tr>
            <th>name</th>
            <th>color</th>
            <th>cost</th>
            <th>put</th>
            <th>patch</th>
            <th>delete</th>
            </tr>
            {posts.map(post => (
            <tr key={post._id.$oid}>
            <td>{post.name}</td>
            <td>{post.color}</td>
            <td>{post.cost}</td>
            <td><Link style={{color:"green"}} to={`/cars/edit/${post._id.$oid}`}><EditOutlined/>put</Link></td>
            <td><Link style={{color:"green"}} to={`/cars/patch/${post._id.$oid}`}><EditOutlined/>patch</Link></td>
            <td><button style={{color:"red"}} onClick={car_delete}value={post._id.$oid}><DeleteOutlined/></button></td>
            </tr>))}
        </table>
        </center>
        </div>
	)
}

export default Fetch