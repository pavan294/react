import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { Form, Input, Button} from 'antd';
import { PlusCircleOutlined } from '@ant-design/icons';
import 'antd/dist/antd.css'; 
function Fetch() {
	const [posts, setPost] = useState({name:'',color:'',cost:''})
    let handler = (e)=>{ 
       console.log(e)
       const post ={name:e.name,color:e.color,cost:e.cost} 
       console.log(post)
       axios
           .post(`http://localhost:5000/cars/`,
           post)
           .then(res => {
               setPost(...posts,post)
               })
           .catch(err =>{
               console.log(err)
           })
    
    }
   return (
		<div>
        <Form onFinish={handler}>
        <Form.Item rules={[{ required: true}]} style={{width:'30%',marginLeft: "600px",marginTop: "50px"}} label="name" name="name">
        <Input placeholder="name" required></Input>
        </Form.Item>
        <Form.Item rules={[{ required: true}]} style={{width:'30%',marginLeft: "600px" }} label="color" name="color">
        <Input placeholder="color" required></Input>
        </Form.Item>
        <Form.Item rules={[{ required: true}]} style={{width:'30%',marginLeft: "600px"}}  label="cost" name="cost">
        <Input placeholder="cost" required></Input>
        </Form.Item>
        <Form.Item rules={[{ required: true }]} style={{ width: "30%",marginLeft: "500px"}} wrapperCol={{ offset: 8, span: 16 }}>
        <Button type="primary" htmlType="submit"><PlusCircleOutlined /></Button>
        </Form.Item>
        </Form><br />
    </div>
	)
}

export default Fetch