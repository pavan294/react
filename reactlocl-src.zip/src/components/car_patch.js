import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { useHistory, useParams } from "react-router-dom";
import { Form, Input, Button} from 'antd';
import {EditOutlined  } from '@ant-design/icons';
function Fetch(props) {
	const [posts, setPost] = useState({name:null,cost:null,color:null})
    const { id } = useParams();
    let Handler = (e)=>{ 
        let post={name:e.name,color:e.color,cost:e.cost}
        axios
            .patch(`http://localhost:5000/cars/${id}`,
            post)
            .then(res => {
                console.log(res.data);
                })
            .catch(err =>{
                console.log(err)
            })
    
    }
	return (
		<div>
          <Form onFinish={Handler}>
        <Form.Item  style={{width:'30%',marginLeft: "600px",marginTop: "50px"}} label="name" name="name">
        <Input placeholder="name"></Input>
        </Form.Item>
        <Form.Item style={{width:'30%',marginLeft: "600px" }} label="color" name="color">
        <Input placeholder="color"></Input>
        </Form.Item>
        <Form.Item style={{width:'30%',marginLeft: "600px"}}  label="cost" name="cost">
        <Input placeholder="cost"></Input>
        </Form.Item>
        <Form.Item style={{ width: "30%",marginLeft: "500px"}} wrapperCol={{ offset: 8, span: 16 }}>
        <Button type="primary" style={{background:"Aqua",color:"red"}} htmlType="submit"><EditOutlined /></Button>
        </Form.Item>
        </Form><br />
        </div>
	)
}

export default Fetch