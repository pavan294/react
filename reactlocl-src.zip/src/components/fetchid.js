import React, { useState} from 'react'
import axios from 'axios'

function DataFetching() {
	const [post, setPost] = useState({name:'',cost:'','color':''})
	const [id, setId] = useState(1)
	const [idFromButtonClick, setIdFromButtonClick] = useState(1)

	const handleClick = () => {
		console.log("clicked")
		setIdFromButtonClick(id)
		axios.get(`http://localhost:5000/cars/${id}`)
			.then(res => {
        const data =res.data[0]
		console.log(res.data[0])
        setPost(data)
			})
			.catch(err => {
				console.log(err)
			})
	}

	return (
		<div>
			<div>{post.name}--{post.color}--{post.cost}</div>
		</div>
	)
}

export default DataFetching