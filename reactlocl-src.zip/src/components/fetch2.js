import React, { useState, useEffect } from 'react'
import axios from 'axios'
import Post from './post'
import Put from './car_put'
import Patch from './car_patch'
import { Link } from "react-router-dom";
import { Table } from 'antd';
function Fetch() {
	const [posts, setPost] = useState([])
    let car_delete= (e) =>{
	    axios.delete(`http://localhost:5000/cars/${e.target.value}`)
			.then(res => {
            setPost(posts.filter(item => item._id !== e.target.value));
			})
			.catch(err => {
				console.log(err)
			})
        
    }
	useEffect(() => {
			axios.get('http://localhost:5000/cars/CarsList')
			.then(res => {
        console.log(res)
        setPost(res.data)
			})
			.catch(err => {
				console.log(err)
			})
	},[])
    const columns = [
        {
          title: "name",
          dataIndex: "name",
          key: 'name',
        },
        {
          title: "color",
          dataIndex: "color",
          key: 'color',
        },
        {
          title: "cost",
          dataIndex: "cost",
          key:'cost',
        }
      ];
    return (
        <div>
      <Link to="/cars/add">Add Car</Link>
      <Table
        columns={columns}
        dataSource={posts}
      />
    </div>
    )}
export default Fetch