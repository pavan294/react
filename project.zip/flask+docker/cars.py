from flask import Flask,jsonify
from flask_restx import Resource, fields, Namespace
from json import JSONDecodeError
from pymongo import MongoClient
import json
import datetime
import pytz
import copy
import io
from utils import car_op
from utils import mechanic_op
import bson
from bson import json_util,ObjectId
client=MongoClient("mongodb://localhost:27017")
db=client.cardb
api1 = Namespace("cars", description="car operations")
carmodel = api1.model('Cars', {
    'name': fields.String,
    'color': fields.String,
    'cost': fields.Integer,
})
parser = api1.parser()
parser.add_argument(
    "name", type=str, required=True
)
parser.add_argument(
    "color", type=str, required=True
)
parser.add_argument(
    "cost", type=int, required=True
)
car_put = api1.parser()
car_put.add_argument(
    "name", type=str, required=True
)
car_put.add_argument(
    "color", type=str, required=True
)
car_put.add_argument(
    "cost", type=int, required=True
)
car_patch = api1.parser()
car_patch.add_argument(
    'color', type=str
    )
car_patch.add_argument(
    'name', type=str
    )
car_patch.add_argument(
    'cost', type=int
    )
car_filter = api1.parser()
car_filter.add_argument(
    'start', type=int, required=True
    )
car_filter.add_argument(
    'limit', type=int, required=True
    )


def abort_if_todo_exist(car_id):
    """[check whether mechanic is assigned]

    Args:
        todo_id ([type]): [int]
    """
    records = mechanic_op.read()
    if isinstance(records, list):
        for record in records:
                for key, value in record.items():
                    if value['car_id'] == car_id:
                        return True
        return False


@api1.route("/mechanics/<int:car_id>")
class Workers(Resource):
    def get(self, car_id):
        """get mechanics for specified car

        Args:
            todo_id ([type]): [car_id]

        Returns:
            [type]: [mechanics list]
        """
        records = mechanic_op.read()
        

@api1.route("/<string:car_id>")
class Todo(Resource):
    def get(self, car_id):
        """get specified car

        Args:
            todo_id ([type]): [int]

        Returns:
            [type]: [mechanic object]
        """
        result = db.cardb.find({"_id":car_id})
        final_result=json.loads(json_util.dumps(result))
        if len(final_result)==0:
            return {"error":"no record found"}
        else:
            return final_result

    def delete(self, car_id):
        """delete car if mechanic is not working

        Args:
            todo_id ([type]): [int]

        Returns:
            [no-content]
        exists=db.cardb.find({"_id":car_id})
        exist_result=json.loads(json_util.dumps(exists))
        if len(exist_result)==0:
           return {"error":"no car found"},404
        """
        result = db.cardb.delete_one({'_id':ObjectId(car_id)})
        return result.raw_result,204

    @api1.expect(car_put, validate=True)
    def put(self, car_id):
        args =car_put.parse_args()
        """Update a given resource
        args =car_put.parse_args()
        exists=db.cardb.find({"_id":ObjectId(car_id)})
        exist_result=json.loads(json_util.dumps(exists))
        if len(exist_result) != 0:
        """
        print(car_id)
        db.cardb.update_one({"_id":ObjectId(car_id)},
                            {"$set":{"name":args['name'],
                            "color":args['color'],
                            "cost":args['cost']}})
        return json.loads(json_util.dumps(args)),200
        '''
        else:
            return {"error":"no car found"},404
        '''
    @api1.expect(carmodel)
    @api1.marshal_with(carmodel, skip_none=True)
    def patch(self,car_id):
        """partially update given resource"""
        args = car_patch.parse_args()
        exists=db.cardb.find({"_id":ObjectId(car_id)})
        exist_result=json.loads(json_util.dumps(exists))
        if len(exist_result)==0:
            return {"error":"no car found"}
        if args['name'] != None:
            db.cardb.update_one({"_id":ObjectId(car_id)},
                {"$set":{"name":args['name']}})
        if args['color'] != None:
            db.cardb.update_one({"_id":ObjectId(car_id)},
                {"$set":{"color":args['color']}})
        if args['cost'] != None:
            db.cardb.update_one({"_id":ObjectId(car_id)},
                {"$set":{"cost":args['cost']}})          
        return args

@api1.route("/")
class TodoList(Resource):
    @api1.doc(parser=parser)
    #@api1.expect(carmodel)
    def post(self):
        """create a car

        Returns:
            [type]: [car object]
        """
        record = parser.parse_args()
        timezone = pytz.timezone('Europe/Berlin')
        date = {"created_at": datetime.datetime.now(timezone).isoformat()}
        record.update(date)
        db.cardb.insert_one(record)
        print(type(record._id),record)
        return json.loads(json_util.dumps(record))
        

@api1.route("/CarsList")
class PaginateList(Resource):
    def get(self):
        """pagination for carlists

        Returns:
            [type]: [car objects]
        """
        results = json.loads(json_util.dumps(db.cardb.find()))
        if results!=[]:
           return results
        else:
            return {"error": "no car found"}, 404

    
@api1.route("/carsfilter")
class CarMultiple(Resource):
    @api1.doc(parser=car_patch)
    def get(self):
        """filter multiple elements"""
        args = car_patch.parse_args()
        initial_results= db.cardb.find()
        results1=json.loads(json_util.dumps(initial_results))
        results=copy.copy(results1)
        for item in results1:
            exists=False
            if args['name'] is not None:
                if item['name']!=args['name']:
                   exists=True
            if args['color'] is not None:
                if item['color']!=args['color']:
                    exists=True
            if args['cost'] is not None:
                if item['cost']!=args['cost']:
                   exists=True
            if exists:
                results.remove(item)
        return results
        
if __name__ == "__main__":
    app = Flask(__name__)
    app.run(debug=True)
