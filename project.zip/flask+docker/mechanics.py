from flask import Flask
from flask_restx import Resource, fields, Namespace
import json
from json import JSONDecodeError
from pymongo import MongoClient
import io
import datetime
import pytz
from utils import mechanic_op
from utils import car_op
from bson import json_util,ObjectId
client=MongoClient("mongodb://localhost:27017")
db=client.mechanicdb
global index
index=0
api = Namespace("mechanics", description="Mechanic operations")
mechanicmodel = api.model('Mechanics', {
    'name': fields.String,
    'car_id': fields.Integer,
})
parser = api.parser()
parser.add_argument(
    "name", type=str, required=True
)
parser.add_argument(
    "car_id", type=int, required=True
)

mechanic_patch = api.parser()
mechanic_patch.add_argument(
    "car_id", type=int
    )
mechanic_patch.add_argument(
    "name", type=str
    )
mechanic_filter = api.parser()
mechanic_filter.add_argument(
    'start', type=int, required=True
    )
mechanic_filter.add_argument(
    'limit', type=int, required=True
    )


def abort_if_todo_doesnt_exist(car_id):
    """[check car exists]

    Args:
        todo_id ([type]): [int]
    """
    records = car_op.read()
    if isinstance(records, list):
        item_exists = 0
        for record in records:
            if str(car_id) in record:
                item_exists = 1
                return True
        if item_exists == 0:
            return False


@api.route("/<int:mechanic_id>")
class Mechanics(Resource):
    def get(self, mechanic_id):
        """[get specific mechanic]

        Args:
            todo_id ([type]): [int]

        Returns:
            [type]: [mechanic objects]
        """
        result = db.mechanicdb.find({"_id":mechanic_id})
        final_result=json.loads(json_util.dumps(result))
        if len(final_result)==0:
            return {"error":"no mechanic found"}
        else:
            return final_result

    @api.doc(responses={204: "mechanic deleted"})
    def delete(self, mechanic_id):
        """[delete specified mechanic]

        Args:
            todo_id ([type]): [int]

        Returns:
            [no_content]
        """
        exists=db.mechanicdb.find({"_id":mechanic_id})
        exist_result=json.loads(json_util.dumps(exists))
        if len(exist_result)==0:
           return {"error":"no mechanic found"},404
        result = db.mechanicdb.delete_one({'_id':mechanic_id})
        return result.raw_result,204      

    @api.doc(parser=parser)
    def put(self, mechanic_id):
        """[update mechanic if car_id is valid]

        Args:
            todo_id ([type]): [int]

        Returns:
            [type]: [mechanic object]
        """
        args =parser.parse_args()
        exists=db.mechanicdb.find({"_id":mechanic_id})
        exist_result=json.loads(json_util.dumps(exists))
        if len(exist_result) != 0:
            db.mechanicdb.update_one({"_id":mechanic_id},
                                {"$set":{"name":args['name'],
                                "car_id":args['car_id']}})
            return json.loads(json_util.dumps(args)),200
        else:
            return {"error":"no mechanic found"},404

    @api.expect(mechanicmodel)
    @api.marshal_with(mechanicmodel, skip_none=True)
    def patch(self, mechanic_id):
        """[partially update mechanic if car_id is valid]

        Args:
            todo_id ([type]): [int]

        Returns:
            [type]: [mechanic object]
        """
        args = mechanic_patch.parse_args()
        exists=db.mechanicdb.find({"_id":mechanic_id})
        exist_result=json.loads(json_util.dumps(exists))
        if len(exist_result)==0:
            return {"error":"no mechanic found"}
        if args['name'] != None:
            db.mechanicdb.update_one({"_id":mechanic_id},
                {"$set":{"name":args['name']}})
        if args['car_id'] != None:
            db.cardb.update_one({"_id":mechanic_id},
                {"$set":{"color":args['color']}})      
        return args

@api.route("/")
class MechanicList(Resource):
    @api.doc(parser=parser)
    def post(self):
        """adds an mechanic

        Returns:
            [type]: [mechanic object]
        """
        args = parser.parse_args()
        timezone = pytz.timezone('Europe/Berlin')
        date_created = {"created_at": datetime.datetime.now(timezone).isoformat()}
        args.update(date_created)
        global index
        args_id={"_id":index}
        index+=1
        args.update(args_id)
        db.mechanicdb.insert_one(args)
        return json.loads(json_util.dumps(args))


@api.route("/MechanicsList")
class PaginateList(Resource):
    @api.doc(parser=mechanic_filter)
    def get(self):
        """pagination for mechaniclists

        Returns:
            [type]: [mechanic objects]
        """
        args = mechanic_filter.parse_args()
        url = "http://127.0.0.1:5000/mechanicspaginate"
        results = mechanic_op.read()
        if isinstance(results, list):
            start = args['start'] 
            limit = args['limit']
            count = len(results)
            if (count < start):
                return {"error": "pagination not possible"}, 404
            obj = {}
            obj['start'] = start
            obj['limit'] = limit
            obj['count'] = count
            if start == 1:
                obj['previous'] = ''
            else:
                start_copy = max(1, start - limit)
                limit_copy = start - 1
                obj['previous'] = url + '?start=%d&limit=%d' % (
                                  start_copy, limit_copy)
            if start + limit == count+1:
                obj['next'] = ''
                obj['results'] = results[(start - 1):(start - 1 + limit)]
            elif start + limit > count+1:
                obj['next'] = ''
            else:
                start_copy = start + limit
                obj['next'] = url + '?start=%d&limit=%d' % (start_copy, limit)
                obj['results'] = results[(start - 1):(start - 1 + limit)]
            return obj, 200
        else:
            return {"error": results}, 404


@api.route("/mechanicsfilter")
class MechanicMultiple(Resource):
    @api.doc(parser=mechanic_patch)
    def get(self):
        """filter multiple elements"""
        args = mechanic_patch.parse_args()
        records = mechanic_op.read()
        if isinstance(records, list):
            new_records = []
            for record in records:
                for key, value in record.items():
                    if((args['name'] == None or
                        args['name'] == value['name']) and
                        (args['car_id'] == None or
                        str(args['car_id']) == value['car_id'])): 
                        new_records.append(record)
                    else:
                        pass
            if new_records == []:
                return {"error": "no mechanic found"}, 404
            return new_records, 200
        else:
            return {"errors": records}, 404


def get_cars(car_id):
    records = car_op.read()
    if isinstance(records, list):
        for record in records:
                if str(car_id) in record:
                    return record
        return {"error": "no car found"}
    else:
        return {"error": "records"}


@api.route("/cars/<int:mechanic_id>")
class WorkerCars(Resource):
    def get(self, mechanic_id):
        """[get cars of mechanic]

        Args:
            mechanic_id ([type]): [int]

        Returns:
            [type]: [mechanic objects]
        """
        records = mechanic_op.read()
        if isinstance(records, list):
            for record in records:
                    if str(mechanic_id) in record:
                        return get_cars(record[str(mechanic_id)]['car_id']), 200
            return {"error": "no mechanic found"}, 404
        else:
            return {"errors": records}, 200

if __name__ == "__main__":
    app = Flask(__name__)
    app.run(debug=True)
