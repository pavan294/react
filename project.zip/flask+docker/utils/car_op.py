import json
import io
from json import JSONDecodeError


def read():
    """reading from cars.json file
    """
    try:
        file = open('data/cars.json', 'r')
    except FileNotFoundError as error:
        return error
    try:
        data = file.read()
    except (io.UnsupportedOperation, NameError) as error:
        return error
    try:
        records = json.loads(data)
        return records
    except JSONDecodeError as error:
        return error
    except TypeError as error:
        return error


def write(records):
    """
    writing to cars.json file
    """
    file = open('data/cars.json', 'w')
    data = json.dumps(records, indent=2)
    try:
        file.write(data)
        file.close()
        return "success"
    except(io.UnsupportedOperation, NameError)as error:
        return error